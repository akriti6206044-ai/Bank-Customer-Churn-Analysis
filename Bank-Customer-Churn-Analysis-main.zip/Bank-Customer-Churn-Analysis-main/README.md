#Customer Churn analysis and Baseline Modelling

#Objective:
--Measure the overall customer churn rate
--Identify high-risk customer segments
--Highlight behavioral and demographic churn drivers
--Support data-driven retention strategies

#Dataset:
--Source: Kaggle.com (Bank Customer Churn Dataset - Gaurav Topre)
--Key columns: customer_id,credit_score,country,gender,age,tenure,balance,products_number,credit_card,active_member,estimated_salary,churn

#Tools and technologies:
--SQL(MySQL):Data storage, querying and aggregation
--Python(pandas,maplotlib)
--Scikit-learn for churn prediction(Logictic Regression)
--Jupyter Notebook(VS Code)
--Power BI

#Analysis and modelling:
--Data injestion and validation in MySQL
--Exploratory data analysis using SQL and Python
--Feature preparationa and train-test split
--Logistic Regression for churn prediction
--Model evaluation using accuracy and confusion matrix
--Business focused visualisation in Power BI

#Power BI
--KPI indicator with churn risk status
--DAX for custom-calculations
--Clear key-insights for executive-decision making

#Conclusion
--This project demonstrates an end-to-end churn analysis pipeline, combining technical analysis with business interpretation and actionable insights.