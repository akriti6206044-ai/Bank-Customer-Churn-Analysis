use bank_churn;
describe customers;

select estimated salary from customers;

alter table customers
change churn exited int;

#exited vs retained
select exited, count(*) from customers group by exited;

#overall churn
select round(avg(exited) * 100, 2) as churn_rate_percent from customers;

#by geography
select country, round(avg(exited) * 100, 2) as churn_rate_percent
from customers
group by country
order by churn_rate_percent desc;

#by active membership
select active_member, round(avg(exited) *100, 2) as churn_rate_percent
from customers
group by active_member;

#by number of products
select products_number, round(avg(exited) * 100, 2) as churn_rate_percent
from customers
group by products_number
order by products_number desc;

select count(products_number) "customers", products_number as "num"
from customers
group by num
order by num;

#by average balance
select exited, round(avg(balance),2) as avg_balance
from customers
group by exited;

select exited, round(avg(estimated_salary),2) as avg_salary
from customers
group by exited;

#by gender
select gender, round(avg(exited)*100, 2) as churn
from customers
group by gender;

#by tenure
select tenure, round(avg(exited)*100, 2) as churn
from customers
group by tenure
order by churn desc;

#by credit score
select min(credit_score), max(credit_score)
from customers;

select
	case
		when credit_score<500 then 'under 500'
			when credit_score between 500 and 700 then 'mid'
					else 'above 700'
						end as cred,
                        round(avg(exited) *100, 2) as churn_rate_percent
                        from customers
                        group by cred
                        order by churn_rate_percent desc;


#by age group
select
	case
		when age<30 then 'under 30'
			when age between 30 and 45 then '30-45'
				when age between 46 and 60 then '46-60'
					else '60+'
						end as age_group,
                        round(avg(exited) *100, 2) as churn_rate_percent
                        from customers
                        group by age_group
                        order by churn_rate_percent desc;

#by credit card ownership
select credit_card, round(avg(exited) * 100,2) as churn_rate_percent
from customers
group by credit_card;

